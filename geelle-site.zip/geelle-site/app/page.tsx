
// GEELLE - Modern Clothing Brand Website
import React from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Phone, MessageSquare } from 'lucide-react';

export default function HomePage() {
  const products = [
    {
      name: "Classic Hoodie",
      image: "https://via.placeholder.com/400x500?text=Classic+Hoodie",
    },
    {
      name: "Urban Jacket",
      image: "https://via.placeholder.com/400x500?text=Urban+Jacket",
    },
    {
      name: "Somali Dress",
      image: "https://via.placeholder.com/400x500?text=Somali+Dress",
    },
    {
      name: "Streetwear Set",
      image: "https://via.placeholder.com/400x500?text=Streetwear+Set",
    }
  ];

  return (
    <div className="min-h-screen bg-white text-black">
      <header className="p-6 shadow-md bg-black text-white">
        <h1 className="text-3xl font-bold">GEELLE</h1>
        <p className="text-sm">Style That Speaks</p>
      </header>

      <section className="p-6 text-center">
        <h2 className="text-2xl font-semibold mb-2">Welcome to GEELLE</h2>
        <p className="mb-4 max-w-xl mx-auto">We create bold, versatile clothing for every style. Reach out on WhatsApp to place your order.</p>
        <Button className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded" onClick={() => window.open('https://wa.me/2520610996962', '_blank')}>Contact on WhatsApp</Button>
      </section>

      <section className="p-6 bg-gray-100">
        <h2 className="text-xl font-semibold mb-4 text-center">Featured Products</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {products.map((product, index) => (
            <Card key={index} className="rounded-xl shadow hover:shadow-lg">
              <img src={product.image} alt={product.name} className="rounded-t-xl w-full h-64 object-cover" />
              <CardContent className="p-4">
                <h3 className="font-semibold text-lg mb-2">{product.name}</h3>
                <Button onClick={() => window.open('https://wa.me/2520610996962', '_blank')} className="bg-green-600 text-white w-full">Order on WhatsApp</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="p-6 text-center">
        <h2 className="text-xl font-semibold mb-2">About GEELLE</h2>
        <p className="max-w-xl mx-auto">GEELLE is a bold clothing brand that blends modern fashion with timeless style. Whether you're dressing for the streets or tradition, GEELLE has something for everyone. We focus on quality, individuality, and style that speaks for itself.</p>
      </section>

      <section className="p-6 bg-gray-100 text-center">
        <h2 className="text-xl font-semibold mb-2">Contact Us</h2>
        <div className="flex flex-col gap-4 items-center">
          <Button variant="outline" className="flex items-center gap-2" onClick={() => window.open('https://wa.me/2520610996962', '_blank')}>
            <MessageSquare className="w-4 h-4" /> Message on WhatsApp
          </Button>
          <Button variant="outline" className="flex items-center gap-2" onClick={() => window.open('tel:+2520610996962', '_blank')}>
            <Phone className="w-4 h-4" /> Call Us
          </Button>
        </div>
      </section>

      <footer className="p-4 text-center text-sm bg-black text-white">
        © {new Date().getFullYear()} GEELLE. All rights reserved.
      </footer>
    </div>
  );
}
