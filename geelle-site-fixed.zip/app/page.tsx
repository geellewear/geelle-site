'use client';
import { Phone, MessageSquare } from 'lucide-react';

export default function HomePage() {
  const products = [
    { name: "Classic Hoodie", image: "https://via.placeholder.com/400x500?text=Classic+Hoodie" },
    { name: "Urban Jacket", image: "https://via.placeholder.com/400x500?text=Urban+Jacket" },
    { name: "Somali Dress", image: "https://via.placeholder.com/400x500?text=Somali+Dress" },
    { name: "Streetwear Set", image: "https://via.placeholder.com/400x500?text=Streetwear+Set" }
  ];

  return (
    <div style={{ fontFamily: 'Arial, sans-serif', background: '#fff', color: '#000' }}>
      <header style={{ padding: '1rem', backgroundColor: '#000', color: '#fff' }}>
        <h1 style={{ fontSize: '2rem', fontWeight: 'bold' }}>GEELLE</h1>
        <p>Style That Speaks</p>
      </header>

      <section style={{ padding: '1rem', textAlign: 'center' }}>
        <h2 style={{ fontSize: '1.5rem', fontWeight: '600' }}>Welcome to GEELLE</h2>
        <p>We create bold, versatile clothing for every style. Reach out on WhatsApp to order.</p>
        <a href="https://wa.me/2520610996962" target="_blank" rel="noopener noreferrer" style={{ background: '#16a34a', color: '#fff', padding: '0.5rem 1rem', display: 'inline-block', marginTop: '1rem', borderRadius: '8px' }}>Contact on WhatsApp</a>
      </section>

      <section style={{ padding: '1rem', backgroundColor: '#f3f3f3' }}>
        <h2 style={{ textAlign: 'center', fontSize: '1.25rem', fontWeight: '600' }}>Featured Products</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '1rem', marginTop: '1rem' }}>
          {products.map((product, index) => (
            <div key={index} style={{ background: '#fff', borderRadius: '12px', overflow: 'hidden', boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
              <img src={product.image} alt={product.name} style={{ width: '100%', height: '300px', objectFit: 'cover' }} />
              <div style={{ padding: '0.75rem' }}>
                <h3>{product.name}</h3>
                <a href="https://wa.me/2520610996962" target="_blank" rel="noopener noreferrer" style={{ background: '#16a34a', color: '#fff', display: 'block', textAlign: 'center', marginTop: '0.5rem', padding: '0.5rem', borderRadius: '6px' }}>Order on WhatsApp</a>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section style={{ padding: '1rem', textAlign: 'center' }}>
        <h2 style={{ fontSize: '1.25rem', fontWeight: '600' }}>About GEELLE</h2>
        <p style={{ maxWidth: '600px', margin: '0 auto' }}>GEELLE is a bold clothing brand that blends modern fashion with timeless style. Whether you're dressing for the streets or tradition, GEELLE has something for everyone. We focus on quality, individuality, and style that speaks for itself.</p>
      </section>

      <section style={{ padding: '1rem', textAlign: 'center', backgroundColor: '#f3f3f3' }}>
        <h2 style={{ fontSize: '1.25rem', fontWeight: '600' }}>Contact Us</h2>
        <div style={{ marginTop: '1rem' }}>
          <a href="https://wa.me/2520610996962" target="_blank" rel="noopener noreferrer" style={{ display: 'inline-block', border: '1px solid #000', padding: '0.5rem 1rem', borderRadius: '6px', marginRight: '1rem' }}><MessageSquare size={16} /> Message on WhatsApp</a>
          <a href="tel:+2520610996962" style={{ display: 'inline-block', border: '1px solid #000', padding: '0.5rem 1rem', borderRadius: '6px' }}><Phone size={16} /> Call Us</a>
        </div>
      </section>

      <footer style={{ background: '#000', color: '#fff', textAlign: 'center', padding: '1rem' }}>
        © {new Date().getFullYear()} GEELLE. All rights reserved.
      </footer>
    </div>
  );
}